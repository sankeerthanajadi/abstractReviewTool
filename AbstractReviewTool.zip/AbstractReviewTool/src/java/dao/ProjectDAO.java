/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Project;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author dell
 */
public class ProjectDAO {
     JdbcTemplate jt;
    public void setJt(JdbcTemplate jt) {
        this.jt = jt;
    }
    
    public List<Project> getProjectsDetails(String userId){
        return jt.query("select * from projects where guide_Id=?",new Object[]{userId},new RowMapper<Project>(){
            public Project mapRow(ResultSet rs, int row) throws SQLException {
                Project p=new Project();
                p.setProjectId(rs.getInt(1));
                p.setProjectTitle(rs.getString(2));
                p.setDomain(rs.getString(3));
                p.setGroupId(rs.getInt(4));
                p.setGuideId(rs.getInt(5));
                p.setStatus(rs.getString(6));
                p.setCreatedDate(rs.getDate(7));
                
                return p;
               }
        });
    }
        
}
