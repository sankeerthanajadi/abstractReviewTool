/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.UserRole;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author dell
 */
public class LoginDAO {
    JdbcTemplate jt;
    public void setJt(JdbcTemplate jt) {
        this.jt = jt;
    }
    public UserRole getUser(String userId, String password,String role){       
        UserRole user=new UserRole();
        return jt.queryForObject("select * from user_role where userID=? and password=? and role=?",new Object[]{userId,password,role},new RowMapper<UserRole>(){;
            
                @Override
                public UserRole mapRow(ResultSet rs, int row) throws SQLException {
                user.setUserrole_id(rs.getInt(1));
                user.setName(rs.getString(2));
                user.setEmail(rs.getString(3));
                user.setPassword(rs.getString(4));
                user.setRole(rs.getString(5));                
                return user;
                }
    });  
       
    }
}
