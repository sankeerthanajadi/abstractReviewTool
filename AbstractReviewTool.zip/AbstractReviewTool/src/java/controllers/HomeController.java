/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import beans.Project;
import dao.ProjectDAO;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author dell
 */
@Controller
public class HomeController {
    @Autowired
    ProjectDAO dao;
    @RequestMapping(path="/fileUploadForm")
    public ModelAndView renderFileUploadPage(HttpServletRequest req){        
        ModelAndView mav=new ModelAndView();         
        mav.setViewName("fileUpload");
        return mav;
    }
    
    @RequestMapping(path="/reviewComments")
    public ModelAndView renderCommentsPage(HttpServletRequest req){        
        ModelAndView mav=new ModelAndView();         
        mav.setViewName("reviewComments");
        return mav;
    }    
    @RequestMapping(path="/generateReport")
    public ModelAndView renderReportGenerationPage(HttpServletRequest req){        
        ModelAndView mav=new ModelAndView();        
        mav.setViewName("generateReport");
        return mav;
    } 
    
    
    
}
