/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import beans.Project;
import beans.UserRole;
import javax.servlet.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dao.LoginDAO;
import dao.ProjectDAO;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author dell
 */

@Controller
@RequestMapping(path="/login")
    public class LoginController {   
    @Autowired
    LoginDAO loginDao;
    @Autowired 
    ProjectDAO projectDao;
    @RequestMapping(method=RequestMethod.GET)
    public ModelAndView renderHome(HttpServletRequest req){
        String userid=req.getParameter("un");
        String password=req.getParameter("pwd");
        String role=req.getParameter("role");
        System.out.println(userid);
          System.out.println(password);
            System.out.println(role);
        UserRole user=loginDao.getUser(userid,password,role);
        ModelAndView mav=new ModelAndView();
        mav.addObject("name",user.getName());
        if(user!=null){
            HttpSession session=req.getSession();
            session.setAttribute("userid", user.getUserId());
            if("student".equals(user.getRole().toLowerCase()))      
                mav.setViewName("studentHome");
            else  if("guide".equals(user.getRole().toLowerCase())){
                List<Project> projects= projectDao.getProjectsDetails(user.getUserId());
                mav.addObject("projects",projects);
                mav.setViewName("guideHome");
            }
                
            else  if("coordinator".equals(user.getRole().toLowerCase()))
                mav.setViewName("coordinatorHome");
            else  if("admin".equals(user.getRole().toLowerCase()))
                mav.setViewName("adminHome");
        }
        else
            mav.setViewName("loginerror");
        return mav;
    }
}
